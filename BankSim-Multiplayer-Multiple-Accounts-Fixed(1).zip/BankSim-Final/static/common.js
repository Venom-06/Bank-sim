const money=x=>Number(x||0).toLocaleString('en-IN',{maximumFractionDigits:2});
async function api(url,method='GET',body){let r=await fetch(url,{method,headers:body?{'Content-Type':'application/json'}:{},body:body?JSON.stringify(body):undefined});let j={};try{j=await r.json()}catch{};return j}
async function loadMe(){return await (await fetch('/api/me')).json()}
