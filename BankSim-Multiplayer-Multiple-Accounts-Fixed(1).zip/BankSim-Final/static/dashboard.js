(function(){
const el=function(id){return document.getElementById(id)};
const money=function(x){return Number(x||0).toLocaleString('en-IN',{maximumFractionDigits:2})};
async function loadDashboard(){
 try{
  const r=await fetch('/api/me',{cache:'no-store'});
  if(!r.ok){throw new Error('Server returned '+r.status)}
  const x=await r.json();
  if(x.error) throw new Error(x.error);
  const b=x.bank,s=x.settings,p=x.last_pl||{};
  if(!b) throw new Error('No bank is linked to this player.');
  const eq=b.reserve+b.personal_loans+b.home_loans+b.bonds_holdings*b.bonds_price/100-b.savings-b.fixed_deposits-b.funding;
  const assets=b.reserve+b.personal_loans+b.home_loans+b.bonds_holdings*b.bonds_price/100;
  const dep=b.savings+b.fixed_deposits;
  const loans=b.personal_loans+b.home_loans;
  el('bankTitle').textContent=b.bank_name;
  el('yearLine').textContent='Quarter '+b.quarter;
  el('equity').textContent=money(eq); el('cap').textContent=money(b.market_cap); el('share').textContent=money(b.stock_price);
  el('inflation').textContent=Number(b.inflation).toFixed(2)+'%'; el('gdp').textContent=money(b.gdp); el('central').textContent=Number(s.central_rate).toFixed(2)+'%';
  el('reserve').textContent=money(b.reserve); el('personal').textContent=money(b.personal_loans); el('home').textContent=money(b.home_loans);
  el('bonds').textContent=money(b.bonds_holdings*b.bonds_price/100); el('assets').textContent=money(assets); el('savings').textContent=money(b.savings); el('fd').textContent=money(b.fixed_deposits); el('funding').textContent=money(b.funding); el('equity2').textContent=money(eq);
  el('car').textContent=(loans?eq/loans*100:0).toFixed(2)+'%'; el('crr').textContent=(dep&&s.crr?b.reserve/(dep*s.crr/100)*100:0).toFixed(2)+'%'; el('ldr').textContent=(dep?loans/dep*100:0).toFixed(2)+'%';
  if(p && Object.keys(p).length){ if(p.customer_inflow!==undefined){ const a=p.allocation||{}; el('inflowBox').innerHTML='<div class="bline"><span>New customer inflow</span><span class="mono">'+money(p.customer_inflow)+'</span></div><div class="bline"><span>Personal loans</span><span class="mono">'+money(a.personal||0)+'</span></div><div class="bline"><span>Home loans</span><span class="mono">'+money(a.home||0)+'</span></div><div class="bline"><span>Bonds</span><span class="mono">'+money(a.bonds||0)+'</span></div><div class="bline"><span>Cash reserve</span><span class="mono">'+money(a.cash||0)+'</span></div>'; } el('pl').innerHTML='<div class="bline"><span>Interest income</span><span class="mono">'+money(p.income&&p.income.total)+'</span></div><div class="bline"><span>Interest expense</span><span class="mono">'+money(p.expense&&p.expense.total)+'</span></div><div class="bline"><span>Net interest income</span><span class="mono">'+money(p.nii)+'</span></div><div class="bline"><span>Provisions</span><span class="mono">'+money(p.provisions)+'</span></div><div class="bline"><span>Operating expenses</span><span class="mono">'+money(p.opex)+'</span></div><div class="bline total"><span>Net profit</span><span class="mono">'+money(p.net)+'</span></div>'}
 }catch(e){el('msg').innerHTML='<div class="err">Dashboard refresh error: '+String(e.message||e).replace(/[<>]/g,'')+'</div>'}
}
document.addEventListener('DOMContentLoaded',function(){
 el('advanceBtn').addEventListener('click',async function(){const btn=el('advanceBtn');btn.disabled=true;try{const r=await fetch('/api/advance',{method:'POST'});const j=await r.json();if(j.error)alert(j.error);else await loadDashboard()}catch(e){alert(e.message)}finally{btn.disabled=false}});
 loadDashboard(); setInterval(loadDashboard,5000);
});
})();