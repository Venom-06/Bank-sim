# BankSim Multiplayer

This build includes the customer-behavior engine, database-driven bank defaults, per-bank allocation strategy, and multiple-player account handling.

## Multiple accounts
Each player is stored in `players` with a unique username and has exactly one bank through `banks.player_id UNIQUE`.

Registering or logging in clears the current browser session and creates a fresh session for the selected account. Existing accounts are not deleted or replaced.

One browser session can be logged into one account at a time. To play two accounts simultaneously, use separate browser profiles/incognito windows or devices.

## Start

```bash
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000/register

If you want a completely fresh game, stop Flask and remove `banksim.db`; the application will recreate it from the database seed defaults.
