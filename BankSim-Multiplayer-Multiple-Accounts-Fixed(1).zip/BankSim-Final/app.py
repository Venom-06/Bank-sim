import os, sqlite3, math, random
from functools import wraps
from flask import Flask, render_template, request, redirect, url_for, session, jsonify, abort
from werkzeug.security import generate_password_hash, check_password_hash

BASE=os.path.dirname(os.path.abspath(__file__))
DB=os.path.join(BASE,'banksim.db')
app=Flask(__name__)
app.secret_key=os.environ.get('BANKSIM_SECRET','change-this-secret')
app.config.update(SESSION_COOKIE_NAME='banksim_session', SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE='Lax')

GAME_SETTINGS={
 'central_rate':4.1,'crr':4,'tax_rate':25,'funding_spread':1,'funding_cap_marketcap_pct':50,
 'opex_asset_rate_quarter':0.0015,'quarter_start_year':2018,'auto_advance_seconds':0,
 'base_customer_inflow_pct':5.0,'customer_rate_sensitivity':1.5,'customer_competitor_sensitivity':1.0,
 'customer_inflation_sensitivity':0.35,'customer_min_inflow_pct':-8.0,'customer_max_inflow_pct':12.0,
 'customer_savings_floor':1.0,'customer_fd_floor':3.0,'customer_zero_rate_penalty':2.5,
 'customer_growth_damping':0.0
}

# These are stored in SQLite in bank_defaults. They are only used to bootstrap
# a brand-new database; after init, the database is the source of truth.
BANK_DEFAULTS={
 'cash':500000000,'personal_loans':300000000,'home_loans':600000000,
 'savings':700000000,'fixed_deposits':500000000,'bonds_holdings':0,
 'bonds_price':100,'shares_outstanding':20000000,'stock_price':100,
 'fd_rate':7,'savings_rate':2.4,'personal_rate':15,'home_rate':9,
 'inflation':4.5,'gdp':240000000000000,'ctc_price':415,
 'customer_inflow_pct':5,'personal_allocation_pct':30,'home_allocation_pct':50,
 'bonds_allocation_pct':10,'cash_allocation_pct':10
}


def db():
    con=sqlite3.connect(DB, timeout=30)
    con.row_factory=sqlite3.Row
    con.execute('PRAGMA foreign_keys=ON')
    con.execute('PRAGMA busy_timeout=30000')
    return con

def init_db():
    con=db(); con.execute('PRAGMA journal_mode=WAL')
    con.executescript('''
    CREATE TABLE IF NOT EXISTS game_settings(key TEXT PRIMARY KEY,value REAL NOT NULL);
    CREATE TABLE IF NOT EXISTS bank_defaults(key TEXT PRIMARY KEY,value REAL NOT NULL);
    CREATE TABLE IF NOT EXISTS players(id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'player', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS banks(
      id INTEGER PRIMARY KEY AUTOINCREMENT, player_id INTEGER UNIQUE NOT NULL REFERENCES players(id) ON DELETE CASCADE,
      bank_name TEXT NOT NULL, reserve REAL NOT NULL, dividend_per_share REAL NOT NULL DEFAULT 0,
      personal_loans REAL NOT NULL, home_loans REAL NOT NULL, savings REAL NOT NULL, fixed_deposits REAL NOT NULL,
      bonds_holdings REAL NOT NULL DEFAULT 0, bonds_price REAL NOT NULL, funding REAL NOT NULL DEFAULT 0,
      shares_outstanding REAL NOT NULL, stock_price REAL NOT NULL, fd_rate REAL NOT NULL, savings_rate REAL NOT NULL,
      personal_rate REAL NOT NULL, home_rate REAL NOT NULL, inflation REAL NOT NULL, gdp REAL NOT NULL,
      quarter INTEGER NOT NULL DEFAULT 0, loan_growth REAL NOT NULL DEFAULT 0, total_assets REAL NOT NULL DEFAULT 0,
      market_cap REAL NOT NULL, ctc_price REAL NOT NULL, ctc_holdings REAL NOT NULL DEFAULT 0,
      systemic_growth REAL NOT NULL DEFAULT 0, peers_in_economy INTEGER NOT NULL DEFAULT 0,
      last_pl TEXT NOT NULL DEFAULT '{}', history TEXT NOT NULL DEFAULT '[]', created_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS bank_allocation_rules(
      bank_id INTEGER PRIMARY KEY REFERENCES banks(id) ON DELETE CASCADE,
      customer_inflow_pct REAL NOT NULL DEFAULT 5,
      personal_allocation_pct REAL NOT NULL DEFAULT 30,
      home_allocation_pct REAL NOT NULL DEFAULT 50,
      bonds_allocation_pct REAL NOT NULL DEFAULT 10,
      cash_allocation_pct REAL NOT NULL DEFAULT 10,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS holdings(id INTEGER PRIMARY KEY AUTOINCREMENT, investor_id INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE, bank_id INTEGER NOT NULL REFERENCES banks(id) ON DELETE CASCADE, shares REAL NOT NULL, avg_price REAL NOT NULL, UNIQUE(investor_id,bank_id));
    CREATE TABLE IF NOT EXISTS transactions(id INTEGER PRIMARY KEY AUTOINCREMENT, player_id INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE, bank_id INTEGER REFERENCES banks(id) ON DELETE CASCADE, market TEXT NOT NULL, side TEXT NOT NULL, qty REAL NOT NULL, price REAL NOT NULL, total REAL NOT NULL, note TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    CREATE TABLE IF NOT EXISTS payouts(id INTEGER PRIMARY KEY AUTOINCREMENT, player_id INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE, bank_id INTEGER REFERENCES banks(id) ON DELETE CASCADE, amount REAL NOT NULL, kind TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
    ''')
    for k,v in GAME_SETTINGS.items(): con.execute('INSERT OR IGNORE INTO game_settings(key,value) VALUES(?,?)',(k,v))
    for k,v in BANK_DEFAULTS.items(): con.execute('INSERT OR IGNORE INTO bank_defaults(key,value) VALUES(?,?)',(k,v))
    rows=con.execute('SELECT id FROM banks WHERE id NOT IN (SELECT bank_id FROM bank_allocation_rules)').fetchall()
    d0={r['key']:r['value'] for r in con.execute('SELECT key,value FROM bank_defaults')}
    for r in rows:
        con.execute('''INSERT INTO bank_allocation_rules(bank_id,customer_inflow_pct,personal_allocation_pct,home_allocation_pct,bonds_allocation_pct,cash_allocation_pct)
                       VALUES(?,?,?,?,?,?)''',(r['id'],d0['customer_inflow_pct'],d0['personal_allocation_pct'],d0['home_allocation_pct'],d0['bonds_allocation_pct'],d0['cash_allocation_pct']))
    cols=[r['name'] for r in con.execute('PRAGMA table_info(banks)').fetchall()]
    if 'multiplier' in cols:
        try: con.execute('ALTER TABLE banks DROP COLUMN multiplier')
        except sqlite3.OperationalError: pass
    con.commit(); con.close()

init_db()

def settings(con=None):
    own=con is None; con=con or db(); out={r['key']:r['value'] for r in con.execute('SELECT key,value FROM game_settings')}
    if own: con.close()
    return out

def current_user():
    uid=session.get('user_id')
    if not uid:return None
    con=db(); r=con.execute('SELECT * FROM players WHERE id=?',(uid,)).fetchone(); con.close(); return r

def login_required(f):
    @wraps(f)
    def w(*a,**kw):
        if not current_user(): return redirect(url_for('login'))
        return f(*a,**kw)
    return w

def admin_required(f):
    @wraps(f)
    def w(*a,**kw):
        u=current_user()
        if not u or u['role']!='admin': abort(403)
        return f(*a,**kw)
    return w

def bank_for_player(con, uid): return con.execute('SELECT * FROM banks WHERE player_id=?',(uid,)).fetchone()
def equity(b): return b['reserve']+b['personal_loans']+b['home_loans']+b['bonds_holdings']*b['bonds_price']/100-b['savings']-b['fixed_deposits']-b['funding']
def total_assets(b): return b['reserve']+b['personal_loans']+b['home_loans']+b['bonds_holdings']*b['bonds_price']/100

def bank_defaults(con=None):
    own=con is None; con=con or db()
    out={r['key']:r['value'] for r in con.execute('SELECT key,value FROM bank_defaults')}
    if own: con.close()
    return out

def allocation_for_bank(con, bank_id):
    r=con.execute('SELECT * FROM bank_allocation_rules WHERE bank_id=?',(bank_id,)).fetchone()
    if r: return dict(r)
    d=bank_defaults(con)
    con.execute('''INSERT INTO bank_allocation_rules(bank_id,customer_inflow_pct,personal_allocation_pct,home_allocation_pct,bonds_allocation_pct,cash_allocation_pct)
                   VALUES(?,?,?,?,?,?)''',(bank_id,d['customer_inflow_pct'],d['personal_allocation_pct'],d['home_allocation_pct'],d['bonds_allocation_pct'],d['cash_allocation_pct']))
    return dict(con.execute('SELECT * FROM bank_allocation_rules WHERE bank_id=?',(bank_id,)).fetchone())

def create_bank(con, player_id, name):
    d=bank_defaults(con)
    cash=d['cash']; loans=d['personal_loans']+d['home_loans']
    assets=cash+d['personal_loans']+d['home_loans']+d['bonds_holdings']*d['bonds_price']/100
    market_cap=d['stock_price']*d['shares_outstanding']
    con.execute('''INSERT INTO banks(
      player_id,bank_name,reserve,personal_loans,home_loans,savings,fixed_deposits,
      bonds_holdings,bonds_price,shares_outstanding,stock_price,fd_rate,savings_rate,
      personal_rate,home_rate,inflation,gdp,market_cap,ctc_price,total_assets
    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',(
      player_id,name,cash,d['personal_loans'],d['home_loans'],d['savings'],d['fixed_deposits'],
      d['bonds_holdings'],d['bonds_price'],d['shares_outstanding'],d['stock_price'],d['fd_rate'],
      d['savings_rate'],d['personal_rate'],d['home_rate'],d['inflation'],d['gdp'],
      market_cap,d['ctc_price'],assets
    ))
    bank_id=con.execute('SELECT id FROM banks WHERE player_id=?',(player_id,)).fetchone()['id']
    con.execute('''INSERT INTO bank_allocation_rules(bank_id,customer_inflow_pct,personal_allocation_pct,home_allocation_pct,bonds_allocation_pct,cash_allocation_pct)
                   VALUES(?,?,?,?,?,?)''',(bank_id,d['customer_inflow_pct'],d['personal_allocation_pct'],d['home_allocation_pct'],d['bonds_allocation_pct'],d['cash_allocation_pct']))

def public_bank(con,b):
    lp=__import__('json').loads(b['last_pl'])
    return dict(id=b['id'],bank_name=b['bank_name'],stock_price=b['stock_price'],market_cap=b['market_cap'],shares_outstanding=b['shares_outstanding'],dividend_per_share=b['dividend_per_share'],quarter=b['quarter'],roe=lp.get('roe',0),total_assets=b['total_assets'],loan_growth=b['loan_growth'])

def log_tx(con, player_id, bank_id, market, side, qty, price, total, note=''):
    con.execute('INSERT INTO transactions(player_id,bank_id,market,side,qty,price,total,note) VALUES(?,?,?,?,?,?,?,?)',(player_id,bank_id,market,side,qty,price,total,note))

def advance_bank(con,b):
    """Advance one bank by one quarter using its stored inflow allocation strategy."""
    import json
    s=settings(con)
    rule=allocation_for_bank(con,b['id'])
    total_alloc=rule['personal_allocation_pct']+rule['home_allocation_pct']+rule['bonds_allocation_pct']+rule['cash_allocation_pct']
    if abs(total_alloc-100)>0.001:
        raise ValueError(f"Bank allocation percentages must total 100%; current total is {total_alloc:.2f}%")
    prev_loans=b['personal_loans']+b['home_loans']
    prev_net=json.loads(b['last_pl'] or '{}').get('net',0)
    assets_pre=total_assets(b)
    deposits_pre=b['savings']+b['fixed_deposits']

    # Customer behavior engine: deposit inflow responds to the bank's rates,
    # competitor rates and inflation. It is bounded so extreme pricing cannot
    # create unlimited deposits or free profit.
    all_banks=con.execute('SELECT savings_rate,fd_rate FROM banks').fetchall()
    competitor_rates=[x['savings_rate']*.6+x['fd_rate']*.4 for x in all_banks]
    competitor_benchmark=(sum(competitor_rates)/len(competitor_rates)) if competitor_rates else (s['central_rate']+1.0)
    own_deposit_rate=b['savings_rate']*.6+b['fd_rate']*.4
    rate_gap=own_deposit_rate-competitor_benchmark
    inflation_gap=b['inflation']-4.0
    attractiveness=(rate_gap*s['customer_rate_sensitivity']
                    + rate_gap*s['customer_competitor_sensitivity']
                    - max(0,inflation_gap)*s['customer_inflation_sensitivity'])
    if b['savings_rate'] < s['customer_savings_floor']:
        attractiveness -= (s['customer_savings_floor']-b['savings_rate'])*s['customer_zero_rate_penalty']
    if b['fd_rate'] < s['customer_fd_floor']:
        attractiveness -= (s['customer_fd_floor']-b['fd_rate'])*s['customer_zero_rate_penalty']*.5
    behavioral_inflow_pct=s['base_customer_inflow_pct']+attractiveness
    behavioral_inflow_pct=max(s['customer_min_inflow_pct'],min(s['customer_max_inflow_pct'],behavioral_inflow_pct))
    target_inflow_pct=(behavioral_inflow_pct*(1-s['customer_growth_damping'])
                       +rule['customer_inflow_pct']*s['customer_growth_damping'])
    target_inflow_pct=max(s['customer_min_inflow_pct'],min(s['customer_max_inflow_pct'],target_inflow_pct))
    customer_inflow=deposits_pre*target_inflow_pct/100

    # New deposits are split between savings and FD. Negative inflow means
    # customers withdraw money instead of supplying deployable new funds.
    savings_inflow=customer_inflow*(b['savings']/deposits_pre) if deposits_pre>0 else customer_inflow
    fd_inflow=customer_inflow-savings_inflow
    savings=max(0,b['savings']+savings_inflow)
    fd=max(0,b['fixed_deposits']+fd_inflow)

    deployable_inflow=max(0,customer_inflow)
    new_personal=deployable_inflow*rule['personal_allocation_pct']/100
    new_home=deployable_inflow*rule['home_allocation_pct']/100
    new_bonds=deployable_inflow*rule['bonds_allocation_pct']/100
    new_cash=deployable_inflow*rule['cash_allocation_pct']/100
    personal=b['personal_loans']+new_personal
    home=b['home_loans']+new_home
    bonds=b['bonds_holdings']+new_bonds
    reserve=max(0,b['reserve']+new_cash+min(0,customer_inflow))

    # Average balances avoid charging a full quarter of interest on new money.
    avg_personal=(b['personal_loans']+personal)/2
    avg_home=(b['home_loans']+home)/2
    avg_bonds=(b['bonds_holdings']+bonds)/2
    avg_savings=(b['savings']+savings)/2
    avg_fd=(b['fixed_deposits']+fd)/2
    income_personal=avg_personal*b['personal_rate']/400
    income_home=avg_home*b['home_rate']/400
    income_bonds=avg_bonds*b['bonds_price']/100*s['central_rate']/400
    exp_s=avg_savings*b['savings_rate']/400
    exp_fd=avg_fd*b['fd_rate']/400
    exp_f=b['funding']*(s['central_rate']+s['funding_spread'])/400
    nii=income_personal+income_home+income_bonds-exp_s-exp_fd-exp_f

    # Credit risk and provisions.
    personal_risk=max(.2,min(9,.4+max(0,(s['central_rate']+6-b['personal_rate']))*.15+max(0,b['inflation']-6)*.1))
    home_risk=max(.1,min(5,.2+max(0,(s['central_rate']+3-b['home_rate']))*.10+max(0,b['inflation']-6)*.05))
    pwo=personal*personal_risk/100
    hwo=home*home_risk/100
    provisions=pwo+hwo
    personal=max(0,personal-pwo)
    home=max(0,home-hwo)

    opex=assets_pre*s['opex_asset_rate_quarter']
    pretax=nii-provisions-opex
    tax=max(0,pretax*s['tax_rate']/100)
    net=pretax-tax
    reserve=max(0,reserve+net)

    # Deposit mix can still react to pricing after the explicit customer inflow.
    sav_spread=b['savings_rate']-s['central_rate']
    fd_spread=b['fd_rate']-s['central_rate']
    savings=max(0,savings*(1+max(-.06,min(.08,sav_spread*.02))))
    fd=max(0,fd*(1+max(-.06,min(.08,fd_spread*.02))))

    new_loans=personal+home
    loan_growth=(new_loans-prev_loans)/prev_loans if prev_loans else 0

    # Shared economy: other banks contribute to systemic growth.
    peers=con.execute('SELECT * FROM banks WHERE id<>?',(b['id'],)).fetchall()
    peer_weight=peer_growth=0
    for p in peers:
        lp=json.loads(p['last_pl'] or '{}')
        size=max(1,p['total_assets'] or p['market_cap'])
        eff=max(.05,min(2.5,(lp.get('roe',0) or 0)/15))
        w=size*eff
        peer_weight+=w
        peer_growth+=w*p['loan_growth']
    peer_g=peer_growth/peer_weight if peer_weight else 0
    own_w=max(1,assets_pre)*max(.05,min(2.5,(json.loads(b['last_pl'] or '{}').get('roe',0) or 0)/15))
    systemic=((loan_growth*own_w)+(peer_g*peer_weight))/(own_w+peer_weight) if peer_weight else loan_growth

    gdp=b['gdp']*(1+max(-.01,min(.03,.005+systemic*.3)))
    inflation=max(0,min(25,b['inflation']+max(-1.5,min(1.5,systemic*8-(s['central_rate']-4)*.15+random.uniform(-.2,.2)))))
    equity_post=reserve+personal+home+bonds*b['bonds_price']/100-savings-fd-b['funding']
    roe=(net*4/equity_post) if equity_post>0 else 0
    # No valuation multiplier: use book value per share with a bounded
    # profitability adjustment and a limited momentum component.
    book_value_per_share=max(.01,equity_post/max(1,b['shares_outstanding']))
    profitability_adjustment=max(-.30,min(.30,roe*2.0))
    fair=max(.01,book_value_per_share*(1+profitability_adjustment))
    surprise=max(-1,min(1,(net-prev_net)/max(1,abs(prev_net))))*.05
    stock=max(.01,(b['stock_price']*.65+fair*.35)*(1+surprise))
    market_cap=stock*b['shares_outstanding']
    ctc=max(.01,b['ctc_price']*(1+(1 if net>0 else -1)*min(.03,abs(net)/max(1,equity_post)*2)))
    q=b['quarter']+1
    eps=net/b['shares_outstanding']
    roa=net*4/assets_pre*100 if assets_pre else 0
    nim=nii*4/assets_pre*100 if assets_pre else 0
    assets_end=reserve+personal+home+bonds*b['bonds_price']/100
    last={'income':{'personal':income_personal,'home':income_home,'bonds':income_bonds,'total':income_personal+income_home+income_bonds},
          'expense':{'savings':exp_s,'fd':exp_fd,'funding':exp_f,'total':exp_s+exp_fd+exp_f},
          'customer_inflow':customer_inflow,
          'customer_inflow_pct':target_inflow_pct,
          'customer_attractiveness':attractiveness,
          'allocation':{'personal':new_personal,'home':new_home,'bonds':new_bonds,'cash':new_cash},
          'allocation_pct':{'personal':rule['personal_allocation_pct'],'home':rule['home_allocation_pct'],'bonds':rule['bonds_allocation_pct'],'cash':rule['cash_allocation_pct']},
          'nii':nii,'provisions':provisions,'opex':opex,'pretax':pretax,'tax':tax,'net':net,'eps':eps,'roe':roe*100,'roa':roa,'nim':nim}
    hist=json.loads(b['history'] or '[]')
    hist.append({'q':q,'equity':equity_post,'sharePrice':stock,'net':net,'eps':eps,'roe':roe*100,'customerInflow':customer_inflow})
    hist=hist[-24:]
    con.execute('''UPDATE banks SET reserve=?,personal_loans=?,home_loans=?,savings=?,fixed_deposits=?,bonds_holdings=?,inflation=?,gdp=?,quarter=?,loan_growth=?,total_assets=?,market_cap=?,stock_price=?,ctc_price=?,systemic_growth=?,peers_in_economy=?,last_pl=?,history=? WHERE id=?''',
      (reserve,personal,home,savings,fd,bonds,inflation,gdp,q,loan_growth,assets_end,market_cap,stock,ctc,systemic,len(peers),json.dumps(last),json.dumps(hist),b['id']))
    return q

def advance_all(con):
    banks=con.execute('SELECT * FROM banks').fetchall()
    for b in banks:
        advance_bank(con,b)
    s=settings(con)
    avg=con.execute('SELECT AVG(inflation) v FROM banks').fetchone()['v'] or bank_defaults(con)['inflation']
    central=max(.5,min(16,s['central_rate']+max(-.4,min(.4,(avg-4)*.08+random.uniform(-.05,.05)))))
    con.execute('UPDATE game_settings SET value=? WHERE key="central_rate"',(central,))
    for b in con.execute('SELECT * FROM banks').fetchall():
        delta=central-s['central_rate']
        bp=max(60,min(140,b['bonds_price']*(1-delta*.04)))
        con.execute('UPDATE banks SET bonds_price=? WHERE id=?',(bp,b['id']))

@app.route('/health')
def health(): return jsonify(ok=True)

@app.route('/')
def home(): return redirect(url_for('dashboard') if current_user() else url_for('login'))
@app.route('/login',methods=['GET','POST'])
def login():
    if request.method=='POST':
        con=db(); u=con.execute('SELECT * FROM players WHERE username=?',(request.form['username'].strip(),)).fetchone(); con.close()
        if u and check_password_hash(u['password_hash'],request.form['password']):
            session.clear()
            session['user_id']=int(u['id'])
            session.modified=True
            return redirect(url_for('dashboard'))
        return render_template('login.html',error='Invalid username or password.')
    return render_template('login.html',error=None)
@app.route('/register',methods=['GET','POST'])
def register():
    if request.method=='POST':
        username=request.form['username'].strip(); bank=request.form['bank_name'].strip() or username+"'s Bank"; pw=request.form['password']
        if not username or not pw:return render_template('register.html',error='Username and password are required.')
        con=db()
        try:
            con.execute('BEGIN'); cur=con.execute('INSERT INTO players(username,password_hash) VALUES(?,?)',(username,generate_password_hash(pw))); create_bank(con,cur.lastrowid,bank); con.commit(); session.clear(); session['user_id']=int(cur.lastrowid); session.modified=True; return redirect(url_for('dashboard'))
        except sqlite3.IntegrityError: con.rollback(); return render_template('register.html',error='That username already exists.')
        except Exception as e:
            con.rollback(); return render_template('register.html',error='Registration error: '+str(e))
        finally: con.close()
    return render_template('register.html',error=None)
@app.route('/logout')
def logout(): session.clear(); return redirect(url_for('login'))

PAGES={'dashboard':'dashboard.html','rates':'rates.html','strategy':'strategy.html','bonds':'bonds.html','loans':'loans.html','shares':'shares.html','market':'market.html','ctc':'ctc.html'}
@app.route('/dashboard')
@login_required
def dashboard():
    u=current_user()
    con=db()
    try:
        b=bank_for_player(con,u['id'])
        if not b:
            session.clear()
            return redirect(url_for('register'))
        import json
        lp=json.loads(b['last_pl'] or '{}')
        s=settings(con)
        return render_template('dashboard.html', user=u, bank=dict(b), settings=s, last_pl=lp)
    finally:
        con.close()

@app.route('/<page>')
@login_required
def page(page):
    if page == 'dashboard': return redirect(url_for('dashboard'))
    if page not in PAGES: abort(404)
    return render_template(PAGES[page], user=current_user())
@app.route('/bank/<int:bank_id>')
@login_required
def bank_detail(bank_id):
    return render_template('bank_detail.html',bank_id=bank_id,user=current_user())
@app.route('/admin')
@admin_required
def admin(): return render_template('admin.html',user=current_user())

@app.route('/api/me')
@login_required
def api_me():
    con=db(); u=current_user(); b=bank_for_player(con,u['id']); s=settings(con)
    if not b:
        con.close(); return jsonify(error='No bank is linked to this player. Please log out and register again.'),404
    lp=__import__('json').loads(b['last_pl'] or '{}'); con.close()
    return jsonify({'player':{'id':u['id'],'username':u['username'],'role':u['role']},'bank':dict(b),'last_pl':lp,'settings':s})
@app.route('/api/settings',methods=['GET','POST'])
@admin_required
def api_settings():
    con=db()
    if request.method=='POST':
        data=request.get_json() or {}
        for k,v in data.items():
            if k in GAME_SETTINGS:
                try: con.execute('UPDATE game_settings SET value=? WHERE key=?',(float(v),k))
                except: pass
        con.commit()
    s=settings(con); con.close(); return jsonify(s)
@app.route('/api/bank-defaults',methods=['GET','POST'])
@admin_required
def api_bank_defaults():
    con=db()
    if request.method=='POST':
        data=request.get_json() or {}
        for k,v in data.items():
            if k in BANK_DEFAULTS:
                try: con.execute('UPDATE bank_defaults SET value=? WHERE key=?',(float(v),k))
                except (TypeError,ValueError): pass
        con.commit()
    out=bank_defaults(con); con.close(); return jsonify(out)

@app.route('/api/rates',methods=['POST'])
@login_required
def api_rates():
    d=request.get_json() or {}; con=db(); b=bank_for_player(con,current_user()['id']); fields={'fd_rate','savings_rate','personal_rate','home_rate'}
    vals=[]
    for k in fields:
        if k in d: vals.append((k,max(0,float(d[k]))))
    for k,v in vals: con.execute(f'UPDATE banks SET {k}=? WHERE id=?',(v,b['id']))
    con.commit(); con.close(); return jsonify(ok=True)
@app.route('/api/allocation',methods=['GET','POST'])
@login_required
def api_allocation():
    con=db(); b=bank_for_player(con,current_user()['id'])
    if not b:
        con.close(); return jsonify(error='No bank is linked to this player.'),404
    if request.method=='POST':
        d=request.get_json() or {}
        keys=['personal_allocation_pct','home_allocation_pct','bonds_allocation_pct','cash_allocation_pct']
        try:
            vals={k:float(d[k]) for k in keys}
        except (KeyError,TypeError,ValueError):
            con.close(); return jsonify(error='All strategy values are required and must be numbers.'),400
        if any(vals[k]<0 for k in keys[1:]):
            con.close(); return jsonify(error='Allocation percentages cannot be negative.'),400
        total=sum(vals[k] for k in keys[1:])
        if abs(total-100)>0.001:
            con.close(); return jsonify(error=f'Allocation must total 100%. Current total is {total:.2f}%.',total=total),400
        existing=con.execute('SELECT customer_inflow_pct FROM bank_allocation_rules WHERE bank_id=?',(b['id'],)).fetchone()
        customer_inflow_default=existing['customer_inflow_pct'] if existing else bank_defaults(con)['customer_inflow_pct']
        con.execute('''INSERT INTO bank_allocation_rules(bank_id,customer_inflow_pct,personal_allocation_pct,home_allocation_pct,bonds_allocation_pct,cash_allocation_pct,updated_at)
                       VALUES(?,?,?,?,?,?,CURRENT_TIMESTAMP)
                       ON CONFLICT(bank_id) DO UPDATE SET personal_allocation_pct=excluded.personal_allocation_pct,
                       home_allocation_pct=excluded.home_allocation_pct,bonds_allocation_pct=excluded.bonds_allocation_pct,
                       cash_allocation_pct=excluded.cash_allocation_pct,updated_at=CURRENT_TIMESTAMP''',
                    (b['id'],customer_inflow_default,vals['personal_allocation_pct'],vals['home_allocation_pct'],vals['bonds_allocation_pct'],vals['cash_allocation_pct']))
        con.commit()
    out=allocation_for_bank(con,b['id']); con.close(); return jsonify(out)

@app.route('/api/advance',methods=['POST'])
@login_required
def api_advance():
    con=db(); advance_all(con); con.commit(); con.close(); return jsonify(ok=True)
@app.route('/api/bonds',methods=['POST'])
@login_required
def api_bonds():
    d=request.get_json() or {}; qty=float(d.get('qty',0)); side=d.get('side'); con=db(); b=bank_for_player(con,current_user()['id']); total=qty*b['bonds_price']/100
    if qty<=0:return jsonify(error='Invalid quantity'),400
    if side=='BUY':
        if b['reserve']<total:return jsonify(error='Not enough reserve'),400
        con.execute('UPDATE banks SET reserve=reserve-?,bonds_holdings=bonds_holdings+? WHERE id=?',(total,qty,b['id']))
    elif side=='SELL':
        if b['bonds_holdings']<qty:return jsonify(error='Not enough bonds'),400
        con.execute('UPDATE banks SET reserve=reserve+?,bonds_holdings=bonds_holdings-? WHERE id=?',(total,qty,b['id']))
    else:return jsonify(error='Invalid side'),400
    log_tx(con,current_user()['id'],b['id'],'Bonds',side,qty,b['bonds_price'],total); con.commit(); con.close(); return jsonify(ok=True)
@app.route('/api/funding',methods=['POST'])
@login_required
def api_funding():
    amount=float((request.get_json() or {}).get('amount',0)); con=db(); b=bank_for_player(con,current_user()['id']); limit=b['market_cap']*settings(con)['funding_cap_marketcap_pct']/100
    if amount<=0 or b['funding']+amount>limit:return jsonify(error='Amount exceeds funding limit'),400
    con.execute('UPDATE banks SET reserve=reserve+?,funding=funding+? WHERE id=?',(amount,amount,b['id'])); log_tx(con,current_user()['id'],b['id'],'Funding','DRAW',amount,1,amount); con.commit(); con.close(); return jsonify(ok=True)
@app.route('/api/buyback',methods=['POST'])
@login_required
def api_buyback():
    qty=float((request.get_json() or {}).get('qty',0)); con=db(); b=bank_for_player(con,current_user()['id']); total=qty*b['stock_price']
    if qty<=0 or b['shares_outstanding']<=qty or b['reserve']<total:return jsonify(error='Invalid quantity or insufficient reserve'),400
    con.execute('UPDATE banks SET reserve=reserve-?,shares_outstanding=shares_outstanding-? WHERE id=?',(total,qty,b['id'])); log_tx(con,current_user()['id'],b['id'],'Shares','BUYBACK',qty,b['stock_price'],total); con.commit(); con.close(); return jsonify(ok=True)
@app.route('/api/dividend',methods=['POST'])
@login_required
def api_dividend():
    d=request.get_json() or {}; dps=float(d.get('dps',0)); con=db(); b=bank_for_player(con,current_user()['id']); holders=con.execute('SELECT * FROM holdings WHERE bank_id=? AND shares>0',(b['id'],)).fetchall(); total=sum(h['shares'] for h in holders)*dps
    if dps<0 or b['reserve']<total:return jsonify(error='Invalid dividend or insufficient reserve'),400
    con.execute('UPDATE banks SET reserve=reserve-?,dividend_per_share=? WHERE id=?',(total,dps,b['id']))
    for h in holders: con.execute('INSERT INTO payouts(player_id,bank_id,amount,kind) VALUES(?,?,?,?)',(h['investor_id'],b['id'],h['shares']*dps,'DIVIDEND'))
    con.commit(); con.close(); return jsonify(ok=True,total=total)
@app.route('/api/ctc',methods=['POST'])
@login_required
def api_ctc():
    d=request.get_json() or {}; qty=float(d.get('qty',0)); side=d.get('side'); con=db(); b=bank_for_player(con,current_user()['id']); total=qty*b['ctc_price']
    if qty<=0:return jsonify(error='Invalid quantity'),400
    if side=='BUY':
        if b['reserve']<total:return jsonify(error='Not enough reserve'),400
        con.execute('UPDATE banks SET reserve=reserve-?,ctc_holdings=ctc_holdings+?,ctc_price=? WHERE id=?',(total,qty,max(.01,b['ctc_price']*(1+min(.05,qty*.000008))),b['id']))
    elif side=='SELL':
        if b['ctc_holdings']<qty:return jsonify(error='Not enough CTC'),400
        con.execute('UPDATE banks SET reserve=reserve+?,ctc_holdings=ctc_holdings-?,ctc_price=? WHERE id=?',(total,qty,max(.01,b['ctc_price']*(1-min(.05,qty*.000008))),b['id']))
    else:return jsonify(error='Invalid side'),400
    log_tx(con,current_user()['id'],b['id'],'CTC',side,qty,b['ctc_price'],total); con.commit(); con.close(); return jsonify(ok=True)
@app.route('/api/banks')
@login_required
def api_banks():
    con=db(); rows=con.execute('SELECT * FROM banks ORDER BY bank_name').fetchall(); out=[public_bank(con,b) for b in rows]; con.close(); return jsonify(out)
@app.route('/api/bank/<int:bank_id>')
@login_required
def api_bank(bank_id):
    con=db(); b=con.execute('SELECT * FROM banks WHERE id=?',(bank_id,)).fetchone()
    if not b: con.close(); abort(404)
    import json; holders=con.execute('SELECT h.*,p.username FROM holdings h JOIN players p ON p.id=h.investor_id WHERE h.bank_id=? AND h.shares>0',(bank_id,)).fetchall(); out=public_bank(con,b); out['last_pl']=json.loads(b['last_pl']); out['holders']=[dict(h) for h in holders]; con.close(); return jsonify(out)
@app.route('/api/trade',methods=['POST'])
@login_required
def api_trade():
    d=request.get_json() or {}; bank_id=int(d.get('bank_id')); qty=float(d.get('qty',0)); side=d.get('side'); uid=current_user()['id']; con=db(); target=con.execute('SELECT * FROM banks WHERE id=?',(bank_id,)).fetchone()
    mine=bank_for_player(con,uid)
    if not target or target['player_id']==uid or qty<=0:return jsonify(error='Invalid bank or quantity'),400
    price=target['stock_price']; total=qty*price; h=con.execute('SELECT * FROM holdings WHERE investor_id=? AND bank_id=?',(uid,bank_id)).fetchone()
    if side=='BUY':
        if mine['reserve']<total:return jsonify(error='Not enough reserve'),400
        if h: con.execute('UPDATE holdings SET shares=shares+?,avg_price=(shares*avg_price+?)/(shares+?) WHERE id=?',(qty,total,qty,h['id']))
        else: con.execute('INSERT INTO holdings(investor_id,bank_id,shares,avg_price) VALUES(?,?,?,?)',(uid,bank_id,qty,price))
        con.execute('UPDATE banks SET reserve=reserve+? WHERE id=?',(total,target['id'])); con.execute('UPDATE banks SET reserve=reserve-? WHERE id=?',(total,mine['id']))
    elif side=='SELL':
        if not h or h['shares']<qty:return jsonify(error='Not enough shares'),400
        new=h['shares']-qty
        if new<=0: con.execute('DELETE FROM holdings WHERE id=?',(h['id'],))
        else: con.execute('UPDATE holdings SET shares=? WHERE id=?',(new,h['id']))
        con.execute('UPDATE banks SET reserve=reserve+? WHERE id=?',(total,mine['id'])); con.execute('UPDATE banks SET reserve=reserve-? WHERE id=?',(total,target['id']))
    else:return jsonify(error='Invalid side'),400
    log_tx(con,uid,mine['id'],'Other Bank Shares',side,qty,price,total,f'target_bank={bank_id}'); con.commit(); con.close(); return jsonify(ok=True)
@app.route('/api/transactions')
@login_required
def api_transactions():
    con=db(); uid=current_user()['id']; rows=con.execute('SELECT * FROM transactions WHERE player_id=? ORDER BY id DESC LIMIT 50',(uid,)).fetchall(); con.close(); return jsonify([dict(r) for r in rows])
@app.route('/api/payouts')
@login_required
def api_payouts():
    con=db(); rows=con.execute('SELECT * FROM payouts WHERE player_id=? ORDER BY id DESC LIMIT 50',(current_user()['id'],)).fetchall(); con.close(); return jsonify([dict(r) for r in rows])
@app.route('/api/admin/reset',methods=['POST'])
@admin_required
def reset_game():
    con=db(); con.execute('DELETE FROM holdings'); con.execute('DELETE FROM transactions'); con.execute('DELETE FROM payouts'); con.execute('DELETE FROM banks'); con.commit(); con.close(); return jsonify(ok=True)

if __name__=='__main__': app.run(host='0.0.0.0',port=int(os.environ.get('PORT',5000)),debug=True)
